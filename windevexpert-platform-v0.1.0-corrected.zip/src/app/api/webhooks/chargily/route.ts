import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get('x-chargily-signature')

    // Récupérer les paramètres de paiement pour la clé secrète
    const paymentSettings = await prisma.paymentSettings.findFirst()

    if (!paymentSettings || !paymentSettings.cibSecretKey) {
      console.error('Configuration Chargily manquante')
      return NextResponse.json({ error: 'Configuration manquante' }, { status: 500 })
    }

    // Vérifier la signature du webhook
    if (signature) {
      const expectedSignature = crypto
        .createHmac('sha256', paymentSettings.cibSecretKey)
        .update(body)
        .digest('hex')

      if (signature !== expectedSignature) {
        console.error('Signature webhook invalide')
        return NextResponse.json({ error: 'Signature invalide' }, { status: 401 })
      }
    }

    const webhookData = JSON.parse(body)
    console.log('Webhook Chargily reçu:', webhookData)

    // Traiter selon le type d'événement
    switch (webhookData.type) {
      case 'checkout.paid':
        await handlePaymentSuccess(webhookData.data)
        break
      case 'checkout.failed':
        await handlePaymentFailure(webhookData.data)
        break
      case 'checkout.expired':
        await handlePaymentExpired(webhookData.data)
        break
      default:
        console.log('Type d\'événement non géré:', webhookData.type)
    }

    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('Erreur lors du traitement du webhook Chargily:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}

async function handlePaymentSuccess(checkoutData: any) {
  try {
    const orderId = checkoutData.order_id || checkoutData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId },
      include: {
        user: true,
        formation: true
      }
    })

    if (!invoice) {
      console.error('Facture non trouvée:', orderId)
      return
    }

    if (invoice.status === 'PAID') {
      console.log('Facture déjà payée:', orderId)
      return
    }

    // Mettre à jour la facture
    await prisma.invoice.update({
      where: { id: orderId },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        externalTransactionId: checkoutData.id || checkoutData.checkout_id
      }
    })

    // Donner accès à la formation
    const existingAccess = await prisma.userFormation.findUnique({
      where: {
        userId_formationId: {
          userId: invoice.userId,
          formationId: invoice.formationId
        }
      }
    })

    if (!existingAccess) {
      await prisma.userFormation.create({
        data: {
          userId: invoice.userId,
          formationId: invoice.formationId,
          accessGrantedAt: new Date()
        }
      })
    }

    // Créer une notification pour l'utilisateur
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_SUCCESS',
        title: 'Paiement réussi',
        message: `Votre paiement pour "${invoice.formation.title}" a été traité avec succès. Vous avez maintenant accès à la formation.`,
        userId: invoice.userId,
        priority: 'MEDIUM',
        relatedId: invoice.id
      }
    })

    // Créer une notification admin
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_SUCCESS',
        title: 'Nouveau paiement CIB',
        message: `Paiement CIB réussi pour ${invoice.user.name} - ${invoice.formation.title} (${invoice.amount} DA)`,
        priority: 'LOW',
        relatedId: invoice.id
      }
    })

    console.log('Paiement traité avec succès:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement du paiement réussi:', error)
  }
}

async function handlePaymentFailure(checkoutData: any) {
  try {
    const orderId = checkoutData.order_id || checkoutData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook d\'échec')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId },
      include: {
        user: true,
        formation: true
      }
    })

    if (!invoice) {
      console.error('Facture non trouvée pour échec:', orderId)
      return
    }

    // Créer une notification pour l'utilisateur
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_FAILED',
        title: 'Échec du paiement',
        message: `Le paiement pour "${invoice.formation.title}" a échoué. Veuillez réessayer ou contacter le support.`,
        userId: invoice.userId,
        priority: 'HIGH',
        relatedId: invoice.id
      }
    })

    console.log('Échec de paiement traité:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement de l\'échec de paiement:', error)
  }
}

async function handlePaymentExpired(checkoutData: any) {
  try {
    const orderId = checkoutData.order_id || checkoutData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook d\'expiration')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId },
      include: {
        user: true,
        formation: true
      }
    })

    if (!invoice) {
      console.error('Facture non trouvée pour expiration:', orderId)
      return
    }

    // Marquer la facture comme expirée
    await prisma.invoice.update({
      where: { id: orderId },
      data: { status: 'CANCELLED' }
    })

    // Créer une notification pour l'utilisateur
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_EXPIRED',
        title: 'Paiement expiré',
        message: `Le lien de paiement pour "${invoice.formation.title}" a expiré. Vous pouvez créer un nouveau paiement.`,
        userId: invoice.userId,
        priority: 'MEDIUM',
        relatedId: invoice.id
      }
    })

    console.log('Expiration de paiement traitée:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement de l\'expiration de paiement:', error)
  }
}