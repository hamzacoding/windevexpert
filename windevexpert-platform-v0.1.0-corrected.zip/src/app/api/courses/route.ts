import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const level = searchParams.get('level')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    const skip = (page - 1) * limit

    // Construire les filtres
    const where: any = {
      product: {
        status: 'ACTIVE'
      }
    }

    if (category && category !== 'all') {
      where.product.category = {
        name: category
      }
    }

    if (level && level !== 'all') {
      where.level = level.toUpperCase()
    }

    // Récupérer les formations
    const [courses, total] = await Promise.all([
      prisma.course.findMany({
        where,
        include: {
          product: {
            include: {
              category: true
            }
          },
          _count: {
            select: {
              enrollments: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.course.count({ where })
    ])

    // Transformer les données pour le frontend
    const formattedCourses = courses.map(course => ({
        id: course.id,
        title: course.title,
        description: course.description,
        duration: `${Math.floor(course.duration / 60)} heures`,
        level: course.level,
        category: course.product.category?.name || 'Non catégorisé',
        priceEuro: course.product.price,
        priceDA: course.product.priceDA,
        students: course._count.enrollments,
        rating: 4.5, // Valeur par défaut, à remplacer par un vrai système de notation
        features: course.product.features ? JSON.parse(course.product.features) : [],
         image: '/api/placeholder/400/250' // Image par défaut
       }))

    return NextResponse.json({
      courses: formattedCourses,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Erreur lors de la récupération des formations:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des formations' },
      { status: 500 }
    )
  }
}