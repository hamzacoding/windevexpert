import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const courseId = params.id

    // Récupérer la formation avec toutes ses relations
    const course = await prisma.course.findUnique({
      where: { 
        id: courseId,
        product: {
          status: 'ACTIVE'
        }
      },
      include: {
        product: {
          include: {
            category: true
          }
        },
        lessons: {
          orderBy: {
            order: 'asc'
          }
        },
        _count: {
          select: {
            enrollments: true
          }
        }
      }
    })

    if (!course) {
      return NextResponse.json(
        { error: 'Formation non trouvée' },
        { status: 404 }
      )
    }

    // Transformer les données pour le frontend
    const formattedCourse = {
      id: course.id,
      title: course.title,
      description: course.description,
      longDescription: course.description, // Utiliser la même description pour l'instant
      duration: `${Math.floor(course.duration / 60)} heures`,
      level: course.level,
      category: course.product.category?.name || 'Non catégorisé',
      priceEuro: course.product.price,
      priceDA: course.product.priceDA,
      studentsCount: course._count.enrollments,
      rating: 4.5, // Valeur par défaut, à remplacer par un vrai système de notation
      features: course.product.features ? JSON.parse(course.product.features) : [],
      image: '/api/placeholder/400/250', // Image par défaut
      objectives: [
        'Objectif 1', // À remplacer par de vraies données
        'Objectif 2',
        'Objectif 3'
      ],
      prerequisites: [
        'Prérequis 1', // À remplacer par de vraies données
        'Prérequis 2'
      ],
      modules: course.lessons.map((lesson, index) => ({
        title: lesson.title,
        duration: `${Math.floor(lesson.duration / 60)}h`,
        lessons: [lesson.description || 'Description du module']
      }))
    }

    return NextResponse.json(formattedCourse)

  } catch (error) {
    console.error('Erreur lors de la récupération de la formation:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la récupération de la formation' },
      { status: 500 }
    )
  }
}