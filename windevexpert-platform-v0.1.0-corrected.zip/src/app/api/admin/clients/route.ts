import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

// GET - Récupérer la liste des clients
export async function GET(request: NextRequest) {
  try {
    // Vérification de l'authentification
    const session = await getServerSession(authOptions)
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Accès non autorisé' },
        { status: 401 }
      )
    }

    // Récupération des paramètres de requête
    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search') || ''
    const limit = parseInt(searchParams.get('limit') || '50')

    // Construction des filtres
    const where: any = {
      role: 'CLIENT' // Seulement les clients, pas les admins
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ]
    }

    // Récupération des clients
    const clients = await prisma.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        image: true,
        createdAt: true,
        _count: {
          select: {
            projects: true,
            orders: true
          }
        }
      },
      orderBy: { name: 'asc' },
      take: limit
    })

    return NextResponse.json({
      clients: clients.map(client => ({
        id: client.id,
        name: client.name,
        email: client.email,
        image: client.image,
        projectsCount: client._count.projects,
        ordersCount: client._count.orders,
        createdAt: client.createdAt.toISOString()
      }))
    })

  } catch (error) {
    console.error('Erreur lors de la récupération des clients:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}