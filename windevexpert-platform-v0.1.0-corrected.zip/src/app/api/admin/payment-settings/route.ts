import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

// Schéma de validation pour les paramètres de paiement
const paymentSettingsSchema = z.object({
  ccpAccount: z.string().optional().or(z.literal('')),
  ccpAccountName: z.string().optional().or(z.literal('')),
  bankAccount: z.string().optional().or(z.literal('')),
  bankAccountName: z.string().optional().or(z.literal('')),
  bankName: z.string().optional().or(z.literal('')),
  slickPayEnabled: z.boolean(),
  slickPayPublicKey: z.string().optional().or(z.literal('')),
  slickPaySecretKey: z.string().optional().or(z.literal('')),
  slickPayTestMode: z.boolean(),
  slickPayWebhookUrl: z.string().optional().or(z.literal('')).refine(
    (val) => !val || val === '' || z.string().url().safeParse(val).success,
    { message: "L'URL webhook doit être une URL valide ou vide" }
  ),
  stripeEnabled: z.boolean(),
  stripePublicKey: z.string().optional().or(z.literal('')),
  stripeSecretKey: z.string().optional().or(z.literal('')),
  stripeTestMode: z.boolean(),
  stripeWebhookSecret: z.string().optional().or(z.literal('')),
  isActive: z.boolean()
})

// GET - Récupérer les paramètres de paiement
export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Accès non autorisé' },
        { status: 401 }
      )
    }

    // Récupérer les paramètres existants
    const settings = await prisma.paymentSettings.findFirst({
      orderBy: { createdAt: 'desc' }
    })

    if (!settings) {
      // Retourner des valeurs par défaut si aucun paramètre n'existe
      return NextResponse.json({
        ccpAccount: '',
        ccpAccountName: '',
        bankAccount: '',
        bankAccountName: '',
        bankName: '',
        slickPayEnabled: false,
        slickPayPublicKey: '',
        slickPaySecretKey: '',
        slickPayTestMode: true,
        slickPayWebhookUrl: '',
        stripeEnabled: false,
        stripePublicKey: '',
        stripeSecretKey: '',
        stripeTestMode: true,
        stripeWebhookSecret: '',
        isActive: true
      })
    }

    // Masquer les clés sensibles dans la réponse
    const response = {
      ...settings,
      slickPayPublicKey: settings.slickPayPublicKey ? '••••••••' : '',
      slickPaySecretKey: settings.slickPaySecretKey ? '••••••••' : '',
      stripePublicKey: settings.stripePublicKey ? '••••••••' : '',
      stripeSecretKey: settings.stripeSecretKey ? '••••••••' : '',
      stripeWebhookSecret: settings.stripeWebhookSecret ? '••••••••' : ''
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error('Erreur lors de la récupération des paramètres:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}

// POST - Sauvegarder les paramètres de paiement
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Accès non autorisé' },
        { status: 401 }
      )
    }

    const body = await request.json()
    
    // Validation des données
    const validatedData = paymentSettingsSchema.parse(body)

    // Récupérer les paramètres existants pour préserver les clés non modifiées
    const existingSettings = await prisma.paymentSettings.findFirst({
      orderBy: { createdAt: 'desc' }
    })

    // Préparer les données à sauvegarder
    const dataToSave = {
      ...validatedData,
      // Préserver les clés existantes si elles ne sont pas modifiées (contiennent des •)
      slickPayPublicKey: validatedData.slickPayPublicKey === '••••••••' 
        ? existingSettings?.slickPayPublicKey 
        : validatedData.slickPayPublicKey,
      slickPaySecretKey: validatedData.slickPaySecretKey === '••••••••' 
        ? existingSettings?.slickPaySecretKey 
        : validatedData.slickPaySecretKey,
      stripePublicKey: validatedData.stripePublicKey === '••••••••' 
        ? existingSettings?.stripePublicKey 
        : validatedData.stripePublicKey,
      stripeSecretKey: validatedData.stripeSecretKey === '••••••••' 
        ? existingSettings?.stripeSecretKey 
        : validatedData.stripeSecretKey,
      stripeWebhookSecret: validatedData.stripeWebhookSecret === '••••••••' 
        ? existingSettings?.stripeWebhookSecret 
        : validatedData.stripeWebhookSecret,
      // Nettoyer les URLs vides
      slickPayWebhookUrl: validatedData.slickPayWebhookUrl === '' 
        ? null 
        : validatedData.slickPayWebhookUrl
    }

    let settings
    if (existingSettings) {
      // Mettre à jour les paramètres existants
      settings = await prisma.paymentSettings.update({
        where: { id: existingSettings.id },
        data: dataToSave
      })
    } else {
      // Créer de nouveaux paramètres
      settings = await prisma.paymentSettings.create({
        data: dataToSave
      })
    }

    // Retourner la réponse sans les clés sensibles
    const response = {
      ...settings,
      slickPayPublicKey: settings.slickPayPublicKey ? '••••••••' : '',
      slickPaySecretKey: settings.slickPaySecretKey ? '••••••••' : '',
      stripePublicKey: settings.stripePublicKey ? '••••••••' : '',
      stripeSecretKey: settings.stripeSecretKey ? '••••••••' : '',
      stripeWebhookSecret: settings.stripeWebhookSecret ? '••••••••' : ''
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error('Erreur lors de la sauvegarde des paramètres:', error)
    
    if (error instanceof z.ZodError) {
      console.error('Erreurs de validation:', error.errors)
      return NextResponse.json(
        { 
          error: 'Données invalides', 
          details: error.errors,
          message: 'Veuillez vérifier les données saisies'
        },
        { status: 400 }
      )
    }

    // Erreur de base de données Prisma
    if (error && typeof error === 'object' && 'code' in error) {
      console.error('Erreur Prisma:', error)
      return NextResponse.json(
        { 
          error: 'Erreur de base de données',
          message: 'Impossible de sauvegarder les paramètres'
        },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { 
        error: 'Erreur interne du serveur',
        message: 'Une erreur inattendue s\'est produite'
      },
      { status: 500 }
    )
  }
}