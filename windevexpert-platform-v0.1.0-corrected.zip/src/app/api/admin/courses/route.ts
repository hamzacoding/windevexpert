import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

// GET - Récupérer toutes les formations avec pagination et filtres
export async function GET(request: NextRequest) {
  try {
    // Vérifier l'authentification
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 })
    }

    // Vérifier les permissions admin
    if (session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    // Récupérer les paramètres de requête
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''
    const level = searchParams.get('level') || ''

    // Construire les conditions de filtrage
    const where: any = {}
    
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }
    
    if (level && level !== 'all') {
      where.level = level
    }

    // Récupérer le nombre total de formations
    const total = await prisma.course.count({ where })

    // Récupérer les formations avec pagination
    const courses = await prisma.course.findMany({
      where,
      include: {
        product: {
          include: {
            category: true
          }
        },
        lessons: {
          select: {
            id: true,
            title: true,
            order: true
          },
          orderBy: {
            order: 'asc'
          }
        },
        enrollments: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      skip: (page - 1) * limit,
      take: limit
    })

    const totalPages = Math.ceil(total / limit)

    return NextResponse.json({
      courses,
      total,
      totalPages,
      currentPage: page
    })
  } catch (error) {
    console.error('Erreur API GET /admin/courses:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des formations' },
      { status: 500 }
    )
  }
}

// POST - Créer une nouvelle formation
export async function POST(request: NextRequest) {
  try {
    // Vérifier l'authentification
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 })
    }

    // Vérifier les permissions admin
    if (session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    const body = await request.json()
    const { 
      title, 
      description, 
      duration, 
      level, 
      isActive = true,
      productData,
      lessons = []
    } = body

    // Validation des données
    if (!title || !description || !duration || !level || !productData) {
      return NextResponse.json(
        { error: 'Données manquantes' },
        { status: 400 }
      )
    }

    // Créer la formation avec le produit associé dans une transaction
    const result = await prisma.$transaction(async (tx) => {
      // Créer le produit d'abord
      const product = await tx.product.create({
        data: {
          name: productData.name,
          description: productData.description,
          price: productData.price,
          priceDA: productData.priceDA || null,
          type: 'FORMATION',
          status: 'ACTIVE',
          categoryId: productData.categoryId,
          features: productData.features || []
        }
      })

      // Créer la formation
      const course = await tx.course.create({
        data: {
          title,
          description,
          duration,
          level,
          isActive,
          productId: product.id
        }
      })

      // Créer les leçons si fournies
      if (lessons.length > 0) {
        await tx.lesson.createMany({
          data: lessons.map((lesson: any, index: number) => ({
            title: lesson.title,
            description: lesson.description || '',
            videoUrl: lesson.videoUrl || '',
            duration: lesson.duration || 0,
            order: lesson.order || index + 1,
            courseId: course.id
          }))
        })
      }

      return course
    })

    // Récupérer la formation complète avec ses relations
    const completeCourse = await prisma.course.findUnique({
      where: { id: result.id },
      include: {
        product: {
          include: {
            category: true
          }
        },
        lessons: {
          orderBy: {
            order: 'asc'
          }
        }
      }
    })

    return NextResponse.json(completeCourse, { status: 201 })
  } catch (error) {
    console.error('Erreur API POST /admin/courses:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la création de la formation' },
      { status: 500 }
    )
  }
}