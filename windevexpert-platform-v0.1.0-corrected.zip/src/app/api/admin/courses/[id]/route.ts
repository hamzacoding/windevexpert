import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

// GET - Récupérer une formation spécifique
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Vérifier l'authentification
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 })
    }

    // Vérifier les permissions admin
    if (session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    // Await params before using
    const { id } = await params

    const course = await prisma.course.findUnique({
      where: { id },
      include: {
        product: {
          include: {
            category: true
          }
        },
        lessons: {
          orderBy: {
            order: 'asc'
          }
        },
        enrollments: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        }
      }
    })

    if (!course) {
      return NextResponse.json(
        { error: 'Formation non trouvée' },
        { status: 404 }
      )
    }

    return NextResponse.json(course)
  } catch (error) {
    console.error('Erreur API GET /admin/courses/[id]:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la récupération de la formation' },
      { status: 500 }
    )
  }
}

// PUT - Mettre à jour une formation
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Vérifier l'authentification
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 })
    }

    // Vérifier les permissions admin
    if (session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    const body = await request.json()
    const { 
      title, 
      description, 
      duration, 
      level, 
      isActive,
      productData,
      lessons = []
    } = body

    // Await params before using
    const { id } = await params

    // Vérifier que la formation existe
    const existingCourse = await prisma.course.findUnique({
      where: { id },
      include: {
        product: true,
        lessons: true
      }
    })

    if (!existingCourse) {
      return NextResponse.json(
        { error: 'Formation non trouvée' },
        { status: 404 }
      )
    }

    // Calculer la durée totale à partir des leçons si fournie, sinon utiliser la durée existante ou 60 par défaut
    let finalDuration = duration
    if (lessons.length > 0) {
      finalDuration = lessons.reduce((total: number, lesson: any) => total + (lesson.duration || 0), 0)
    }
    // Si la durée est toujours 0 ou null, utiliser une valeur par défaut
    if (!finalDuration || finalDuration <= 0) {
      finalDuration = existingCourse.duration > 0 ? existingCourse.duration : 60 // 1 heure par défaut
    }

    // Mettre à jour dans une transaction
    const result = await prisma.$transaction(async (tx) => {
      // Mettre à jour le produit associé si des données sont fournies
      if (productData) {
        await tx.product.update({
          where: { id: existingCourse.productId },
          data: {
            name: productData.name,
            description: productData.description,
            price: productData.price,
            priceDA: productData.priceDA || null,
            categoryId: productData.categoryId,
            features: productData.features
          }
        })
      }

      // Mettre à jour la formation
      const updatedCourse = await tx.course.update({
        where: { id },
        data: {
          title,
          description,
          duration: finalDuration,
          level,
          isActive
        }
      })

      // Gérer les leçons si fournies
      if (lessons.length > 0) {
        // Supprimer les anciennes leçons
        await tx.lesson.deleteMany({
          where: { courseId: id }
        })

        // Créer les nouvelles leçons
        await tx.lesson.createMany({
          data: lessons.map((lesson: any, index: number) => ({
            title: lesson.title,
            description: lesson.description || '',
            videoUrl: lesson.videoUrl || '',
            duration: lesson.duration || 0,
            order: lesson.order || index + 1,
            courseId: id
          }))
        })
      }

      return updatedCourse
    })

    // Récupérer la formation mise à jour avec ses relations
    const completeCourse = await prisma.course.findUnique({
      where: { id },
      include: {
        product: {
          include: {
            category: true
          }
        },
        lessons: {
          orderBy: {
            order: 'asc'
          }
        },
        enrollments: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json(completeCourse)
  } catch (error) {
    console.error('Erreur API PUT /admin/courses/[id]:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour de la formation' },
      { status: 500 }
    )
  }
}

// DELETE - Supprimer une formation
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Vérifier l'authentification
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Non authentifié' }, { status: 401 })
    }

    // Vérifier les permissions admin
    if (session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    // Await params before using
    const { id } = await params

    // Vérifier que la formation existe
    const existingCourse = await prisma.course.findUnique({
      where: { id },
      include: {
        product: true,
        enrollments: true
      }
    })

    if (!existingCourse) {
      return NextResponse.json(
        { error: 'Formation non trouvée' },
        { status: 404 }
      )
    }

    // Vérifier s'il y a des inscriptions actives
    if (existingCourse.enrollments.length > 0) {
      return NextResponse.json(
        { error: 'Impossible de supprimer une formation avec des inscriptions actives' },
        { status: 400 }
      )
    }

    // Supprimer dans une transaction
    await prisma.$transaction(async (tx) => {
      // Supprimer les leçons
      await tx.lesson.deleteMany({
        where: { courseId: id }
      })

      // Supprimer la formation
      await tx.course.delete({
        where: { id }
      })

      // Optionnel : supprimer le produit associé si pas d'autres références
      // Pour l'instant, on garde le produit pour l'historique
    })

    return NextResponse.json({ message: 'Formation supprimée avec succès' })
  } catch (error) {
    console.error('Erreur API DELETE /admin/courses/[id]:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la suppression de la formation' },
      { status: 500 }
    )
  }
}