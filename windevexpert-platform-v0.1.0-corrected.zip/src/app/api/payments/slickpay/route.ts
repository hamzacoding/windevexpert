import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import axios from 'axios'

const slickPayPaymentSchema = z.object({
  formationId: z.string(),
  amount: z.number().positive(),
  currency: z.literal('DZD')
})

export async function POST(request: NextRequest) {
  try {
    // Récupération de la session utilisateur
    const session = await getServerSession(authOptions)
    
    // TEMPORAIRE: Contourner l'authentification pour les tests
    let userEmail = session?.user?.email
    if (!userEmail) {
      userEmail = 'test@windevexpert.com'
    }

    let user = await prisma.user.findUnique({
      where: { email: userEmail }
    })

    // TEMPORAIRE: Créer un utilisateur de test si nécessaire
    if (!user && userEmail === 'test@windevexpert.com') {
      user = await prisma.user.create({
        data: {
          email: 'test@windevexpert.com',
          name: 'Test User',
          role: 'CLIENT'
        }
      })
    }

    if (!user) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      )
    }

    const body = await request.json()
    const { formationId, amount, currency } = slickPayPaymentSchema.parse(body)

    // Récupérer la formation et son produit associé
    const course = await prisma.course.findUnique({
      where: { id: formationId },
      include: {
        product: true
      }
    })

    if (!course) {
      return NextResponse.json({ error: 'Formation non trouvée' }, { status: 404 })
    }

    const formation = course.product

    // Vérifier que le prix en dinars existe
    if (!formation.priceDA) {
      return NextResponse.json({ 
        error: 'Prix en dinars non configuré pour cette formation' 
      }, { status: 400 })
    }

    // Utiliser le prix en dinars depuis la base de données
    const amountDA = formation.priceDA

    // Récupérer les paramètres de paiement
    const paymentSettings = await prisma.paymentSettings.findFirst()

    if (!paymentSettings || !paymentSettings.slickPayPublicKey) {
      return NextResponse.json({ error: 'Configuration SlickPay manquante' }, { status: 500 })
    }

    // Vérifier si une facture impayée existe déjà
    const existingInvoice = await prisma.invoice.findFirst({
      where: {
        userId: user.id,
        productId: formation.id,
        status: {
          in: ['UNPAID', 'PROOF_UPLOADED']
        }
      }
    })

    if (existingInvoice) {
      return NextResponse.json({ 
        error: 'Une facture impayée existe déjà pour cette formation',
        invoiceId: existingInvoice.id
      }, { status: 400 })
    }

    // Créer une facture
    const invoiceNumber = `INV-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    
    const invoice = await prisma.invoice.create({
      data: {
        invoiceNumber,
        userId: user.id,
        productId: formation.id,
        productName: formation.name,
        productPrice: formation.price,
        totalAmount: amountDA,
        currency: 'DZD',
        paymentMethod: 'SLICKPAY',
        status: 'UNPAID',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 jours
      }
    })

    // Étape 1: Créer un contact SlickPay d'abord
    const contactApiUrl = paymentSettings.slickPayTestMode 
      ? 'https://devapi.slick-pay.com/api/v2/users/contacts'
      : 'https://prodapi.slick-pay.com/api/v2/users/contacts'

    // Générer un RIB fictif de 20 chiffres (requis par SlickPay)
    const generateRIB = () => {
      return Math.random().toString().slice(2, 22).padEnd(20, '0')
    }

    const contactData = {
      rib: generateRIB(),
      firstname: user.name?.split(' ')[0] || 'Client',
      lastname: user.name?.split(' ').slice(1).join(' ') || 'Utilisateur',
      email: user.email,
      address: 'Adresse non spécifiée'
    }

    let contactUuid
    try {
      const contactResult = await axios.post(contactApiUrl, contactData, {
        headers: {
          'Authorization': `Bearer ${paymentSettings.slickPayPublicKey}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      })
      contactUuid = contactResult.data.uuid
    } catch (contactError) {
      console.error('Erreur lors de la création du contact SlickPay:', contactError?.response?.data)
      
      // Vérifier si c'est un problème d'authentification
      if (contactError?.response?.data?.message === 'Unauthenticated.') {
        return NextResponse.json({ 
          error: 'Configuration SlickPay invalide. Veuillez vérifier vos clés API dans les paramètres.',
          details: 'Les clés API SlickPay ne sont pas valides ou sont expirées.'
        }, { status: 500 })
      }
      
      return NextResponse.json({ 
        error: 'Erreur lors de la création du contact SlickPay',
        details: contactError?.response?.data
      }, { status: 500 })
    }

    // Étape 2: Créer la facture avec l'UUID du contact
    const slickPayData = {
      amount: amountDA, // Montant en centimes (ex: 10000 = 100.00 DA)
      contact: contactUuid, // UUID du contact créé
      url: `${process.env.NEXTAUTH_URL}/dashboard/payment/success?invoice=${invoice.id}`, // URL de retour
      items: [
        {
          name: formation.name,
          price: amountDA,
          quantity: 1
        }
      ]
    }

    // Utiliser l'API SlickPay v2 selon la documentation officielle
    const slickPayApiUrl = paymentSettings.slickPayTestMode 
      ? 'https://devapi.slick-pay.com/api/v2/users/invoices'
      : 'https://prodapi.slick-pay.com/api/v2/users/invoices'

    const slickPayResult = await axios.post(slickPayApiUrl, slickPayData, {
      headers: {
        'Authorization': `Bearer ${paymentSettings.slickPayPublicKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    })

    if (!slickPayResult || slickPayResult.status !== 200 && slickPayResult.status !== 201) {
      console.error('Erreur SlickPay:', slickPayResult?.data)
      return NextResponse.json({ 
        error: 'Erreur lors de la création du paiement SlickPay',
        details: slickPayResult?.data
      }, { status: 500 })
    }

    const responseData = slickPayResult.data

    // Mettre à jour la facture avec l'ID de transaction SlickPay
    await prisma.invoice.update({
      where: { id: invoice.id },
      data: {
        // Ajouter le champ externalTransactionId si nécessaire dans le schéma
        notes: `SlickPay Transaction ID: ${responseData?.id || responseData?.payment_id}`
      }
    })

    return NextResponse.json({
      success: true,
      invoice: {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber
      },
      slickpay: {
        payment_url: responseData?.data?.url, // URL de paiement SATIM selon la doc
        payment_id: responseData?.data?.id || responseData?.id
      }
    })

  } catch (error) {
    console.error('Erreur lors de la création du paiement SlickPay:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}