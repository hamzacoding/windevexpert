import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const chargilyPaymentSchema = z.object({
  formationId: z.string(),
  amount: z.number().positive(),
  currency: z.literal('DZD')
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'Utilisateur non trouvé' }, { status: 404 })
    }

    const body = await request.json()
    const { formationId, amount, currency } = chargilyPaymentSchema.parse(body)

    // Récupérer la formation et le produit associé
    const formation = await prisma.course.findUnique({
      where: { id: formationId },
      include: {
        product: true
      }
    })

    if (!formation || !formation.product) {
      return NextResponse.json({ error: 'Formation non trouvée ou produit non associé' }, { status: 404 })
    }

    // Récupérer les paramètres de paiement
    const paymentSettings = await prisma.paymentSettings.findFirst()

    if (!paymentSettings || !paymentSettings.cibApiKey || !paymentSettings.cibSecretKey) {
      return NextResponse.json({ error: 'Configuration Chargily manquante' }, { status: 500 })
    }

    // Vérifier si une facture impayée existe déjà
    const existingInvoice = await prisma.invoice.findFirst({
      where: {
        userId: user.id,
        productId: formation.product.id,
        status: {
          in: ['PENDING', 'PROOF_UPLOADED']
        }
      }
    })

    if (existingInvoice) {
      return NextResponse.json({ 
        error: 'Une facture impayée existe déjà pour cette formation',
        invoiceId: existingInvoice.id
      }, { status: 400 })
    }

    // Créer une facture
    const invoiceNumber = `INV-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    
    const invoice = await prisma.invoice.create({
      data: {
        invoiceNumber,
        userId: user.id,
        productId: formation.product.id,
        productName: formation.title,
        productPrice: amount,
        currency: currency,
        paymentMethod: 'CIB',
        totalAmount: amount,
        status: 'PENDING',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 jours
      }
    })

    // Préparer les données pour Chargily Pay
    const chargilyData = {
      mode: 'EDAHABIA', // EDAHABIA ou CIB
      amount: amount,
      currency: 'dzd',
      order_id: invoice.id,
      client: {
        name: user.name || 'Client',
        email: user.email
      },
      back_urls: {
        success: `${process.env.NEXTAUTH_URL}/dashboard/payment/success?invoice=${invoice.id}`,
        failure: `${process.env.NEXTAUTH_URL}/dashboard/payment/failure?invoice=${invoice.id}`
      },
      webhook_endpoint: `${process.env.NEXTAUTH_URL}/api/webhooks/chargily`,
      description: `Paiement pour la formation: ${formation.title}`,
      metadata: {
        invoice_id: invoice.id,
        user_id: user.id,
        formation_id: formationId
      }
    }

    // Déterminer l'URL de l'API selon le mode test
    const apiUrl = paymentSettings.cibTestMode 
      ? 'https://pay.chargily.com/test/api/v2/checkouts'
      : 'https://pay.chargily.com/api/v2/checkouts'

    // Appel à l'API Chargily Pay V2
    const chargilyResponse = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${paymentSettings.cibApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(chargilyData)
    })

    if (!chargilyResponse.ok) {
      const errorData = await chargilyResponse.json()
      console.error('Erreur Chargily:', errorData)
      return NextResponse.json({ 
        error: 'Erreur lors de la création du paiement Chargily',
        details: errorData
      }, { status: 500 })
    }

    const chargilyResult = await chargilyResponse.json()

    // Mettre à jour la facture avec l'ID de transaction Chargily
    await prisma.invoice.update({
      where: { id: invoice.id },
      data: {
        externalTransactionId: chargilyResult.id || chargilyResult.checkout_id
      }
    })

    return NextResponse.json({
      success: true,
      invoice: {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber
      },
      chargily: {
        checkout_url: chargilyResult.checkout_url,
        checkout_id: chargilyResult.id || chargilyResult.checkout_id
      }
    })

  } catch (error) {
    console.error('Erreur lors de la création du paiement Chargily:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}