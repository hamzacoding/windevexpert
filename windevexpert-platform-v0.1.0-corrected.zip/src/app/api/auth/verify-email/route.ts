import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { VerificationTokenService, TokenType } from '@/lib/verification-token'
import { EmailWorkflowService } from '@/lib/services/email-workflow-service'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const token = searchParams.get('token')

    if (!token) {
      return NextResponse.json(
        { message: 'Token de vérification manquant' },
        { status: 400 }
      )
    }

    // Verify the token
    const tokenData = await VerificationTokenService.verifyAndGetTokenData(token, TokenType.EMAIL_VERIFICATION)

    if (!tokenData) {
      return NextResponse.json(
        { message: 'Token de vérification invalide ou expiré' },
        { status: 400 }
      )
    }

    // Find the user
    const user = await prisma.user.findUnique({
      where: { email: tokenData.identifier }
    })

    if (!user) {
      return NextResponse.json(
        { message: 'Utilisateur non trouvé' },
        { status: 404 }
      )
    }

    // Check if email is already verified
    if (user.emailVerified) {
      return NextResponse.json(
        { message: 'Email déjà vérifié' },
        { status: 200 }
      )
    }

    // Update user to mark email as verified
    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerified: new Date()
      }
    })

    // Delete the verification token
    await VerificationTokenService.deleteToken(token)

    // Send welcome email
    await EmailWorkflowService.sendWelcomeEmail(user.email, user.name || 'Utilisateur')

    return NextResponse.json(
      { 
        message: 'Email vérifié avec succès ! Votre compte est maintenant actif.',
        verified: true
      },
      { status: 200 }
    )

  } catch (error) {
    console.error('Email verification error:', error)
    return NextResponse.json(
      { message: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email } = body

    if (!email) {
      return NextResponse.json(
        { message: 'Email requis' },
        { status: 400 }
      )
    }

    // Find the user
    const user = await prisma.user.findUnique({
      where: { email }
    })

    if (!user) {
      return NextResponse.json(
        { message: 'Utilisateur non trouvé' },
        { status: 404 }
      )
    }

    // Check if email is already verified
    if (user.emailVerified) {
      return NextResponse.json(
        { message: 'Email déjà vérifié' },
        { status: 400 }
      )
    }

    // Generate new verification token
    const verificationToken = await VerificationTokenService.createVerificationToken(email, TokenType.EMAIL_VERIFICATION)
    
    // Create verification URL
    const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000'
    const verificationUrl = `${baseUrl}/auth/verify-email?token=${verificationToken}`

    // Send verification email
    try {
      await EmailWorkflowService.sendEmailVerificationEmail(email, {
        userName: user.name || 'Utilisateur',
        verificationUrl
      })
    } catch (emailError) {
      console.error('Erreur lors de l\'envoi de l\'email de vérification:', emailError)
      return NextResponse.json(
        { message: 'Erreur lors de l\'envoi de l\'email' },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { message: 'Email de vérification renvoyé avec succès' },
      { status: 200 }
    )

  } catch (error) {
    console.error('Resend verification error:', error)
    return NextResponse.json(
      { message: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}