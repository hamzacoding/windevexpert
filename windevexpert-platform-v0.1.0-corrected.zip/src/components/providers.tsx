'use client'

import { SessionProvider } from 'next-auth/react'
import { LoadingProvider } from '@/contexts/loading-context'
import { CartProvider } from '@/contexts/cart-context'
import { ToastProvider } from '@/contexts/toast-context'

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <LoadingProvider>
        <ToastProvider>
          <CartProvider>
            {children}
          </CartProvider>
        </ToastProvider>
      </LoadingProvider>
    </SessionProvider>
  )
}