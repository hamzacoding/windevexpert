import { prisma } from '@/lib/prisma'

export interface AdminStats {
  totalUsers: number
  totalProducts: number
  totalCategories: number
  recentUsers: Array<{
    id: string
    name: string | null
    email: string
    role: string
    createdAt: Date
  }>
  usersByRole: {
    CLIENT: number
    ADMIN: number
  }
  monthlyGrowth: {
    users: number
    products: number
  }
}

export async function getAdminStats(): Promise<AdminStats> {
  try {
    // Statistiques générales
    const [totalUsers, totalProducts, totalCategories] = await Promise.all([
      prisma.user.count(),
      prisma.product.count(),
      prisma.category.count()
    ])

    // Utilisateurs récents (derniers 5)
    const recentUsers = await prisma.user.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        createdAt: true
      }
    })

    // Répartition par rôle
    const usersByRole = await prisma.user.groupBy({
      by: ['role'],
      _count: {
        role: true
      }
    })

    const roleStats = {
      CLIENT: usersByRole.find(r => r.role === 'CLIENT')?._count.role || 0,
      ADMIN: usersByRole.find(r => r.role === 'ADMIN')?._count.role || 0
    }

    // Croissance mensuelle (utilisateurs créés ce mois)
    const currentMonth = new Date()
    currentMonth.setDate(1)
    currentMonth.setHours(0, 0, 0, 0)

    const [monthlyUsers, monthlyProducts] = await Promise.all([
      prisma.user.count({
        where: {
          createdAt: {
            gte: currentMonth
          }
        }
      }),
      prisma.product.count({
        where: {
          createdAt: {
            gte: currentMonth
          }
        }
      })
    ])

    return {
      totalUsers,
      totalProducts,
      totalCategories,
      recentUsers,
      usersByRole: roleStats,
      monthlyGrowth: {
        users: monthlyUsers,
        products: monthlyProducts
      }
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des statistiques admin:', error)
    throw new Error('Impossible de récupérer les statistiques')
  }
}

export async function getUsersWithPagination(page: number = 1, limit: number = 10) {
  try {
    const skip = (page - 1) * limit

    const [users, totalCount] = await Promise.all([
      prisma.user.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          isBlocked: true,
          blockedAt: true,
          blockedReason: true,
          createdAt: true,
          updatedAt: true
        }
      }),
      prisma.user.count()
    ])

    return {
      users,
      totalCount,
      totalPages: Math.ceil(totalCount / limit),
      currentPage: page
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des utilisateurs:', error)
    throw new Error('Impossible de récupérer les utilisateurs')
  }
}

export async function getProductsWithPagination(page: number = 1, limit: number = 10) {
  try {
    const skip = (page - 1) * limit

    const [products, totalCount] = await Promise.all([
      prisma.product.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          category: {
            select: {
              name: true
            }
          }
        }
      }),
      prisma.product.count()
    ])

    return {
      products,
      totalCount,
      totalPages: Math.ceil(totalCount / limit),
      currentPage: page
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des produits:', error)
    throw new Error('Impossible de récupérer les produits')
  }
}