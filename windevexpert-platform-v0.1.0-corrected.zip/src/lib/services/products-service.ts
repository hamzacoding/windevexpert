import { prisma } from '@/lib/prisma'

export interface ProductData {
  // Informations de base
  name: string
  slug?: string
  description: string
  type: 'FORMATION' | 'SERVICE' | 'PRODUCT'
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED'
  categoryId: string
  
  // Informations générales
  logo?: string
  version?: string
  publishedAt?: Date
  
  // Description détaillée
  tagline?: string
  shortDescription?: string
  targetAudience?: string
  problemSolved?: string
  keyBenefits?: string[]
  
  // Fonctionnalités
  features?: string[]
  screenshots?: string[]
  demoUrl?: string
  videoUrl?: string
  
  // Détails techniques
  appType?: string
  compatibility?: string[]
  languages?: string[]
  technologies?: string[]
  requirements?: string
  hosting?: string
  security?: string
  
  // Tarification
  price: number
  priceDA?: number
  isFree: boolean
  pricingPlans?: any[]
  trialPeriod?: number
  paymentMethods?: string[]
  
  // Support
  supportTypes?: string[]
  documentation?: string
  training?: string
  updatePolicy?: string
  
  // Témoignages
  testimonials?: any[]
  caseStudies?: any[]
  partners?: string[]
  
  // Légal
  termsOfUse?: string
  privacyPolicy?: string
  license?: string
  
  // Deprecated
  image?: string
}

export interface ProductsResponse {
  products: any[]
  totalCount: number
  totalPages: number
  currentPage: number
}

// Récupérer tous les produits avec pagination et filtres
export async function getProducts(
  page: number = 1,
  limit: number = 10,
  search: string = '',
  type: string = '',
  status: string = '',
  category: string = ''
): Promise<ProductsResponse> {
  const skip = (page - 1) * limit

  // Construire les conditions de filtrage
  const where: any = {}

  if (search) {
    where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } }
    ]
  }

  if (type && type !== 'all') {
    where.type = type
  }

  if (status && status !== 'all') {
    where.status = status
  }

  if (category && category !== 'all') {
    where.categoryId = category
  }

  try {
    const [products, totalCount] = await Promise.all([
      prisma.product.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          category: {
            select: {
              id: true,
              name: true
            }
          },
          _count: {
            select: {
              orderItems: true,
              reviews: true
            }
          }
        }
      }),
      prisma.product.count({ where })
    ])

    const totalPages = Math.ceil(totalCount / limit)

    return {
      products: products.map(product => ({
        ...product,
        enrollments: product._count.orderItems,
        reviewCount: product._count.reviews,
        rating: 4.5, // TODO: Calculer la moyenne des notes des reviews
        // Parse JSON fields
        features: product.features ? JSON.parse(product.features) : [],
        keyBenefits: product.keyBenefits ? JSON.parse(product.keyBenefits) : [],
        screenshots: product.screenshots ? JSON.parse(product.screenshots) : [],
        compatibility: product.compatibility ? JSON.parse(product.compatibility) : [],
        languages: product.languages ? JSON.parse(product.languages) : [],
        technologies: product.technologies ? JSON.parse(product.technologies) : [],
        pricingPlans: product.pricingPlans ? JSON.parse(product.pricingPlans) : [],
        paymentMethods: product.paymentMethods ? JSON.parse(product.paymentMethods) : [],
        supportTypes: product.supportTypes ? JSON.parse(product.supportTypes) : [],
        testimonials: product.testimonials ? JSON.parse(product.testimonials) : [],
        caseStudies: product.caseStudies ? JSON.parse(product.caseStudies) : [],
        partners: product.partners ? JSON.parse(product.partners) : []
      })),
      totalCount,
      totalPages,
      currentPage: page
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des produits:', error)
    throw new Error('Impossible de récupérer les produits')
  }
}

// Récupérer un produit par ID
export async function getProductById(id: string) {
  try {
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        category: {
          select: {
            id: true,
            name: true
          }
        },
        _count: {
          select: {
            orderItems: true,
            reviews: true
          }
        }
      }
    })

    if (!product) {
      throw new Error('Produit non trouvé')
    }

    return {
      ...product,
      enrollments: product._count.orderItems,
      reviewCount: product._count.reviews,
      rating: 4.5, // TODO: Calculer la moyenne des notes des reviews
      // Parse JSON fields
      features: product.features ? JSON.parse(product.features) : [],
      keyBenefits: product.keyBenefits ? JSON.parse(product.keyBenefits) : [],
      screenshots: product.screenshots ? JSON.parse(product.screenshots) : [],
      compatibility: product.compatibility ? JSON.parse(product.compatibility) : [],
      languages: product.languages ? JSON.parse(product.languages) : [],
      technologies: product.technologies ? JSON.parse(product.technologies) : [],
      pricingPlans: product.pricingPlans ? JSON.parse(product.pricingPlans) : [],
      paymentMethods: product.paymentMethods ? JSON.parse(product.paymentMethods) : [],
      supportTypes: product.supportTypes ? JSON.parse(product.supportTypes) : [],
      testimonials: product.testimonials ? JSON.parse(product.testimonials) : [],
      caseStudies: product.caseStudies ? JSON.parse(product.caseStudies) : [],
      partners: product.partners ? JSON.parse(product.partners) : []
    }
  } catch (error) {
    console.error('Erreur lors de la récupération du produit:', error)
    throw new Error('Impossible de récupérer le produit')
  }
}

// Créer un nouveau produit
export async function createProduct(data: ProductData) {
  try {
    const product = await prisma.product.create({
      data: {
        name: data.name,
        slug: data.slug || data.name.toLowerCase().replace(/\s+/g, '-'),
        description: data.description,
        type: data.type,
        status: data.status,
        categoryId: data.categoryId,
        
        // Informations générales
        logo: data.logo,
        version: data.version,
        publishedAt: data.publishedAt,
        
        // Description détaillée
        tagline: data.tagline,
        shortDescription: data.shortDescription,
        targetAudience: data.targetAudience,
        problemSolved: data.problemSolved,
        keyBenefits: data.keyBenefits ? JSON.stringify(data.keyBenefits) : null,
        
        // Fonctionnalités
        features: data.features ? JSON.stringify(data.features) : null,
        screenshots: data.screenshots ? JSON.stringify(data.screenshots) : null,
        demoUrl: data.demoUrl,
        videoUrl: data.videoUrl,
        
        // Détails techniques
        appType: data.appType,
        compatibility: data.compatibility ? JSON.stringify(data.compatibility) : null,
        languages: data.languages ? JSON.stringify(data.languages) : null,
        technologies: data.technologies ? JSON.stringify(data.technologies) : null,
        requirements: data.requirements,
        hosting: data.hosting,
        security: data.security,
        
        // Tarification
        price: data.price,
        priceDA: data.priceDA,
        isFree: data.isFree,
        pricingPlans: data.pricingPlans ? JSON.stringify(data.pricingPlans) : null,
        trialPeriod: data.trialPeriod,
        paymentMethods: data.paymentMethods ? JSON.stringify(data.paymentMethods) : null,
        
        // Support
        supportTypes: data.supportTypes ? JSON.stringify(data.supportTypes) : null,
        documentation: data.documentation,
        training: data.training,
        updatePolicy: data.updatePolicy,
        
        // Témoignages
        testimonials: data.testimonials ? JSON.stringify(data.testimonials) : null,
        caseStudies: data.caseStudies ? JSON.stringify(data.caseStudies) : null,
        partners: data.partners ? JSON.stringify(data.partners) : null,
        
        // Légal
        termsOfUse: data.termsOfUse,
        privacyPolicy: data.privacyPolicy,
        license: data.license,
        
        // Deprecated
        image: data.image
      },
      include: {
        category: {
          select: {
            id: true,
            name: true
          }
        },
        _count: {
          select: {
            orderItems: true,
            reviews: true
          }
        }
      }
    })

    return {
      ...product,
      enrollments: product._count.orderItems,
      reviewCount: product._count.reviews,
      rating: 4.5,
      // Parse JSON fields
      features: product.features ? JSON.parse(product.features) : [],
      keyBenefits: product.keyBenefits ? JSON.parse(product.keyBenefits) : [],
      screenshots: product.screenshots ? JSON.parse(product.screenshots) : [],
      compatibility: product.compatibility ? JSON.parse(product.compatibility) : [],
      languages: product.languages ? JSON.parse(product.languages) : [],
      technologies: product.technologies ? JSON.parse(product.technologies) : [],
      pricingPlans: product.pricingPlans ? JSON.parse(product.pricingPlans) : [],
      paymentMethods: product.paymentMethods ? JSON.parse(product.paymentMethods) : [],
      supportTypes: product.supportTypes ? JSON.parse(product.supportTypes) : [],
      testimonials: product.testimonials ? JSON.parse(product.testimonials) : [],
      caseStudies: product.caseStudies ? JSON.parse(product.caseStudies) : [],
      partners: product.partners ? JSON.parse(product.partners) : []
    }
  } catch (error) {
    console.error('Erreur lors de la création du produit:', error)
    throw new Error('Impossible de créer le produit')
  }
}

// Mettre à jour un produit
export async function updateProduct(id: string, data: Partial<ProductData>) {
  try {
    const updateData: any = {}
    
    // Informations de base
    if (data.name) updateData.name = data.name
    if (data.slug) updateData.slug = data.slug
    if (data.description !== undefined) {
      updateData.description = data.description
    }
    if (data.type) updateData.type = data.type
    if (data.status) updateData.status = data.status
    if (data.categoryId) updateData.categoryId = data.categoryId
    
    // Informations générales
    if (data.logo !== undefined) updateData.logo = data.logo
    if (data.version !== undefined) updateData.version = data.version
    if (data.publishedAt !== undefined) updateData.publishedAt = data.publishedAt
    
    // Description détaillée
    if (data.tagline !== undefined) updateData.tagline = data.tagline
    if (data.shortDescription !== undefined) updateData.shortDescription = data.shortDescription
    if (data.targetAudience !== undefined) updateData.targetAudience = data.targetAudience
    if (data.problemSolved !== undefined) updateData.problemSolved = data.problemSolved
    if (data.keyBenefits !== undefined) updateData.keyBenefits = data.keyBenefits ? JSON.stringify(data.keyBenefits) : null
    
    // Fonctionnalités
    if (data.features !== undefined) updateData.features = data.features ? JSON.stringify(data.features) : null
    if (data.screenshots !== undefined) updateData.screenshots = data.screenshots ? JSON.stringify(data.screenshots) : null
    if (data.demoUrl !== undefined) updateData.demoUrl = data.demoUrl
    if (data.videoUrl !== undefined) updateData.videoUrl = data.videoUrl
    
    // Détails techniques
    if (data.appType !== undefined) updateData.appType = data.appType
    if (data.compatibility !== undefined) updateData.compatibility = data.compatibility ? JSON.stringify(data.compatibility) : null
    if (data.languages !== undefined) updateData.languages = data.languages ? JSON.stringify(data.languages) : null
    if (data.technologies !== undefined) updateData.technologies = data.technologies ? JSON.stringify(data.technologies) : null
    if (data.requirements !== undefined) updateData.requirements = data.requirements
    if (data.hosting !== undefined) updateData.hosting = data.hosting
    if (data.security !== undefined) updateData.security = data.security
    
    // Tarification
    if (data.price !== undefined) updateData.price = data.price
    if (data.priceDA !== undefined) updateData.priceDA = data.priceDA
    if (data.isFree !== undefined) updateData.isFree = data.isFree
    if (data.pricingPlans !== undefined) updateData.pricingPlans = data.pricingPlans ? JSON.stringify(data.pricingPlans) : null
    if (data.trialPeriod !== undefined) updateData.trialPeriod = data.trialPeriod
    if (data.paymentMethods !== undefined) updateData.paymentMethods = data.paymentMethods ? JSON.stringify(data.paymentMethods) : null
    
    // Support
    if (data.supportTypes !== undefined) updateData.supportTypes = data.supportTypes ? JSON.stringify(data.supportTypes) : null
    if (data.documentation !== undefined) updateData.documentation = data.documentation
    if (data.training !== undefined) updateData.training = data.training
    if (data.updatePolicy !== undefined) updateData.updatePolicy = data.updatePolicy
    
    // Témoignages
    if (data.testimonials !== undefined) updateData.testimonials = data.testimonials ? JSON.stringify(data.testimonials) : null
    if (data.caseStudies !== undefined) updateData.caseStudies = data.caseStudies ? JSON.stringify(data.caseStudies) : null
    if (data.partners !== undefined) updateData.partners = data.partners ? JSON.stringify(data.partners) : null
    
    // Légal
    if (data.termsOfUse !== undefined) updateData.termsOfUse = data.termsOfUse
    if (data.privacyPolicy !== undefined) updateData.privacyPolicy = data.privacyPolicy
    if (data.license !== undefined) updateData.license = data.license
    
    // Deprecated
    if (data.image !== undefined) updateData.image = data.image
    
    const product = await prisma.product.update({
      where: { id },
      data: updateData,
      include: {
        category: {
          select: {
            id: true,
            name: true
          }
        },
        _count: {
          select: {
            orderItems: true,
            reviews: true
          }
        }
      }
    })

    return {
      ...product,
      enrollments: product._count.orderItems,
      reviewCount: product._count.reviews,
      rating: 4.5,
      // Parse JSON fields
      features: product.features ? JSON.parse(product.features) : [],
      keyBenefits: product.keyBenefits ? JSON.parse(product.keyBenefits) : [],
      screenshots: product.screenshots ? JSON.parse(product.screenshots) : [],
      compatibility: product.compatibility ? JSON.parse(product.compatibility) : [],
      languages: product.languages ? JSON.parse(product.languages) : [],
      technologies: product.technologies ? JSON.parse(product.technologies) : [],
      pricingPlans: product.pricingPlans ? JSON.parse(product.pricingPlans) : [],
      paymentMethods: product.paymentMethods ? JSON.parse(product.paymentMethods) : [],
      supportTypes: product.supportTypes ? JSON.parse(product.supportTypes) : [],
      testimonials: product.testimonials ? JSON.parse(product.testimonials) : [],
      caseStudies: product.caseStudies ? JSON.parse(product.caseStudies) : [],
      partners: product.partners ? JSON.parse(product.partners) : []
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour du produit:', error)
    throw new Error('Impossible de mettre à jour le produit')
  }
}

// Supprimer un produit
export async function deleteProduct(id: string) {
  try {
    // Vérifier s'il y a des commandes liées à ce produit
    const orderItemsCount = await prisma.orderItem.count({
      where: { productId: id }
    })

    if (orderItemsCount > 0) {
      throw new Error('Impossible de supprimer un produit qui a des commandes associées')
    }

    await prisma.product.delete({
      where: { id }
    })

    return { success: true }
  } catch (error) {
    console.error('Erreur lors de la suppression du produit:', error)
    throw new Error('Impossible de supprimer le produit')
  }
}

// Récupérer les statistiques des produits
export async function getProductStats() {
  try {
    const [
      totalProducts,
      activeProducts,
      draftProducts,
      totalRevenue,
      productsByType
    ] = await Promise.all([
      prisma.product.count(),
      prisma.product.count({ where: { status: 'ACTIVE' } }),
      prisma.product.count({ where: { status: 'DRAFT' } }),
      prisma.order.aggregate({
        _sum: { amount: true },
        where: { status: 'COMPLETED' }
      }),
      prisma.product.groupBy({
        by: ['type'],
        _count: { type: true }
      })
    ])

    return {
      totalProducts,
      activeProducts,
      draftProducts,
      totalRevenue: totalRevenue._sum.amount || 0,
      productsByType: productsByType.reduce((acc, item) => {
        acc[item.type] = item._count.type
        return acc
      }, {} as Record<string, number>)
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des statistiques:', error)
    throw new Error('Impossible de récupérer les statistiques des produits')
  }
}

// Récupérer les catégories uniques
export async function getProductCategories() {
  try {
    const categories = await prisma.category.findMany({
      select: { 
        id: true,
        name: true 
      },
      orderBy: { name: 'asc' }
    })

    return categories
  } catch (error) {
    console.error('Erreur lors de la récupération des catégories:', error)
    throw new Error('Impossible de récupérer les catégories')
  }
}