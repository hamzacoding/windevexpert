-- AlterTable
ALTER TABLE "AppSettings" ADD COLUMN "geminiApiKey" TEXT;
ALTER TABLE "AppSettings" ADD COLUMN "openaiApiKey" TEXT;
