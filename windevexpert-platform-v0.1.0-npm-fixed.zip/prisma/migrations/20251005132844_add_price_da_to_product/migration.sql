-- AlterTable
ALTER TABLE "Product" ADD COLUMN "priceDA" REAL;
