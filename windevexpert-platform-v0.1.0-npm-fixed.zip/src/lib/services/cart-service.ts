import { prisma } from '@/lib/prisma'
import { Cart, CartItem, Product } from '@/types/product'

export class CartService {
  static async getCart(userId?: string, sessionId?: string): Promise<Cart | null> {
    try {
      if (!userId && !sessionId) {
        throw new Error('Either userId or sessionId must be provided')
      }

      const cart = await prisma.cart.findFirst({
        where: userId ? { userId } : { sessionId },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      })

      if (!cart) return null

      // Transform Prisma cart to our Cart type
      return {
        id: cart.id,
        userId: cart.userId || undefined,
        sessionId: cart.sessionId || undefined,
        items: cart.items.map(item => ({
          productId: item.productId,
          product: {
            id: item.product.id,
            name: item.product.name,
            slug: item.product.slug,
            description: item.product.description,
            price: item.product.price,
            priceDA: item.product.priceDA,
            type: item.product.type,
            status: item.product.status,
            image: item.product.logo,
            features: item.product.features,
            categoryId: item.product.categoryId
          } as Product,
          quantity: item.quantity,
          price: item.price,
          addedAt: item.createdAt
        })),
        total: cart.total,
        currency: 'EUR',
        createdAt: cart.createdAt,
        updatedAt: cart.updatedAt
      }
    } catch (error) {
      console.error('Error fetching cart:', error)
      return null
    }
  }

  static async createCart(userId?: string, sessionId?: string): Promise<Cart> {
    try {
      if (!userId && !sessionId) {
        throw new Error('Either userId or sessionId must be provided')
      }

      const cart = await prisma.cart.create({
        data: {
          userId,
          sessionId,
          total: 0
        },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      })

      return {
        id: cart.id,
        userId: cart.userId || undefined,
        sessionId: cart.sessionId || undefined,
        items: [],
        total: 0,
        currency: 'EUR',
        createdAt: cart.createdAt,
        updatedAt: cart.updatedAt
      }
    } catch (error) {
      console.error('Error creating cart:', error)
      throw new Error('Failed to create cart')
    }
  }

  static async addToCart(
    productId: string,
    quantity: number = 1,
    userId?: string,
    sessionId?: string
  ): Promise<Cart> {
    try {
      // Get or create cart
      let cart = await this.getCart(userId, sessionId)
      if (!cart) {
        cart = await this.createCart(userId, sessionId)
      }

      // Get product details
      const product = await prisma.product.findUnique({
        where: { id: productId }
      })

      if (!product) {
        throw new Error('Product not found')
      }

      // Check if product is already in cart
      const existingItem = await prisma.cartItem.findUnique({
        where: {
          cartId_productId: {
            cartId: cart.id,
            productId
          }
        }
      })

      if (existingItem) {
        // Update quantity of existing item
        await prisma.cartItem.update({
          where: { id: existingItem.id },
          data: { quantity: existingItem.quantity + quantity }
        })
      } else {
        // Add new item to cart
        await prisma.cartItem.create({
          data: {
            cartId: cart.id,
            productId,
            quantity,
            price: product.price
          }
        })
      }

      // Recalculate and update cart total
      const updatedCart = await this.updateCartTotal(cart.id)
      return updatedCart
    } catch (error) {
      console.error('Error adding to cart:', error)
      throw new Error('Failed to add product to cart')
    }
  }

  static async updateCartItem(
    cartId: string,
    productId: string,
    quantity: number
  ): Promise<Cart> {
    try {
      if (quantity <= 0) {
        // Remove item if quantity is 0 or negative
        await prisma.cartItem.delete({
          where: {
            cartId_productId: {
              cartId,
              productId
            }
          }
        })
      } else {
        // Update quantity
        await prisma.cartItem.update({
          where: {
            cartId_productId: {
              cartId,
              productId
            }
          },
          data: { quantity }
        })
      }

      // Recalculate and update cart total
      const updatedCart = await this.updateCartTotal(cartId)
      return updatedCart
    } catch (error) {
      console.error('Error updating cart item:', error)
      throw new Error('Failed to update cart item')
    }
  }

  static async removeFromCart(
    cartId: string,
    productId: string
  ): Promise<Cart> {
    try {
      return await this.updateCartItem(cartId, productId, 0)
    } catch (error) {
      console.error('Error removing from cart:', error)
      throw new Error('Failed to remove product from cart')
    }
  }

  static async clearCart(cartId: string): Promise<Cart> {
    try {
      // Delete all cart items
      await prisma.cartItem.deleteMany({
        where: { cartId }
      })

      // Update cart total
      await prisma.cart.update({
        where: { id: cartId },
        data: { total: 0 }
      })

      // Return updated cart
      const cart = await prisma.cart.findUnique({
        where: { id: cartId },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      })
      
      if (!cart) {
        throw new Error('Cart not found after clearing')
      }

      return cart
    } catch (error) {
      console.error('Error clearing cart:', error)
      throw new Error('Failed to clear cart')
    }
  }

  static async mergeGuestCartWithUserCart(
    sessionId: string,
    userId: string
  ): Promise<Cart | null> {
    try {
      // Get guest cart
      const guestCart = await this.getCart(undefined, sessionId)
      if (!guestCart || guestCart.items.length === 0) {
        return null
      }

      // Get or create user cart
      let userCart = await this.getCart(userId)
      if (!userCart) {
        userCart = await this.createCart(userId)
      }

      // Merge items from guest cart to user cart
      for (const guestItem of guestCart.items) {
        const existingItem = await prisma.cartItem.findUnique({
          where: {
            cartId_productId: {
              cartId: userCart.id,
              productId: guestItem.productId
            }
          }
        })

        if (existingItem) {
          // Add quantities if product already exists
          await prisma.cartItem.update({
            where: { id: existingItem.id },
            data: { quantity: existingItem.quantity + guestItem.quantity }
          })
        } else {
          // Add new item
          await prisma.cartItem.create({
            data: {
              cartId: userCart.id,
              productId: guestItem.productId,
              quantity: guestItem.quantity,
              price: guestItem.price
            }
          })
        }
      }

      // Delete guest cart
      await this.deleteCart(guestCart.id)

      // Return updated user cart
      const updatedUserCart = await this.updateCartTotal(userCart.id)
      return updatedUserCart
    } catch (error) {
      console.error('Error merging carts:', error)
      throw new Error('Failed to merge carts')
    }
  }

  static async getCartItemCount(userId?: string, sessionId?: string): Promise<number> {
    try {
      const cart = await this.getCart(userId, sessionId)
      if (!cart) return 0

      // Return the number of distinct products, not the sum of quantities
      return cart.items.length
    } catch (error) {
      console.error('Error getting cart item count:', error)
      return 0
    }
  }

  static async deleteCart(cartId: string): Promise<void> {
    try {
      // Delete cart (cascade will delete cart items)
      await prisma.cart.delete({
        where: { id: cartId }
      })
    } catch (error) {
      console.error('Error deleting cart:', error)
      throw new Error('Failed to delete cart')
    }
  }

  private static async updateCartTotal(cartId: string): Promise<Cart> {
    try {
      // Calculate total from cart items
      const cartItems = await prisma.cartItem.findMany({
        where: { cartId }
      })

      const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)

      // Update cart total
      await prisma.cart.update({
        where: { id: cartId },
        data: { total }
      })

      // Return updated cart
      const cart = await prisma.cart.findUnique({
        where: { id: cartId },
        include: {
          items: {
            include: {
              product: true
            }
          }
        }
      })

      if (!cart) {
        throw new Error('Cart not found')
      }

      return {
        id: cart.id,
        userId: cart.userId || undefined,
        sessionId: cart.sessionId || undefined,
        items: cart.items.map(item => ({
          productId: item.productId,
          product: {
            id: item.product.id,
            name: item.product.name,
            slug: item.product.slug,
            description: item.product.description,
            price: item.product.price,
            priceDA: item.product.priceDA,
            type: item.product.type,
            status: item.product.status,
            image: item.product.logo,
            features: item.product.features,
            categoryId: item.product.categoryId
          } as Product,
          quantity: item.quantity,
          price: item.price,
          addedAt: item.createdAt
        })),
        total: cart.total,
        currency: 'EUR',
        createdAt: cart.createdAt,
        updatedAt: cart.updatedAt
      }
    } catch (error) {
      console.error('Error updating cart total:', error)
      throw error
    }
  }
}