import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// GET - Récupérer les paramètres de contact (API publique)
export async function GET() {
  try {
    // Récupérer les paramètres de contact
    let settings = await prisma.contactSettings.findFirst();
    
    // Si aucun paramètre n'existe, retourner des valeurs par défaut
    if (!settings) {
      settings = {
        id: '',
        email: 'contact@windevexpert.com',
        phone: '+33 1 23 45 67 89',
        whatsapp: '+33 6 12 34 56 78',
        address: 'Paris, France',
        facebook: '',
        twitter: '',
        linkedin: '',
        instagram: '',
        youtube: '',
        github: '',
        openingHours: JSON.stringify({
          monday: { open: '09:00', close: '18:00', closed: false },
          tuesday: { open: '09:00', close: '18:00', closed: false },
          wednesday: { open: '09:00', close: '18:00', closed: false },
          thursday: { open: '09:00', close: '18:00', closed: false },
          friday: { open: '09:00', close: '18:00', closed: false },
          saturday: { open: '09:00', close: '12:00', closed: false },
          sunday: { open: '09:00', close: '12:00', closed: true }
        }),
        companyName: 'WinDevExpert',
        description: 'Expert en développement WinDev, WebDev et WinDev Mobile',
        createdAt: new Date(),
        updatedAt: new Date()
      };
    }

    // Parser les horaires d'ouverture si elles existent
    let parsedOpeningHours = null;
    if (settings.openingHours) {
      try {
        parsedOpeningHours = JSON.parse(settings.openingHours);
      } catch (error) {
        console.error('Erreur lors du parsing des horaires d\'ouverture:', error);
      }
    }

    // Retourner les paramètres avec les horaires parsées
    return NextResponse.json({
      ...settings,
      openingHours: parsedOpeningHours
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des paramètres de contact:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des paramètres' },
      { status: 500 }
    );
  }
}