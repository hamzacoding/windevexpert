import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const { cartId, userId, sessionId } = await request.json()

    // Get payment settings from database
    const paymentSettings = await prisma.paymentSettings.findFirst({
      where: { isActive: true },
      select: {
        stripeEnabled: true,
        stripeSecretKey: true,
        stripeTestMode: true
      }
    })

    if (!paymentSettings?.stripeEnabled || !paymentSettings?.stripeSecretKey) {
      return NextResponse.json(
        { error: 'Stripe n\'est pas configuré ou activé' },
        { status: 400 }
      )
    }

    // Check if we're using dummy test keys (for development/testing)
    const isDummyKey = paymentSettings.stripeSecretKey.includes('1234567890') || 
                      paymentSettings.stripeSecretKey.length < 50

    let stripe: Stripe | null = null
    
    if (!isDummyKey) {
      // Initialize Stripe with real keys
      stripe = new Stripe(paymentSettings.stripeSecretKey, {
        apiVersion: '2024-06-20',
      })
    }

    // Get cart data
    const cart = await prisma.cart.findFirst({
      where: {
        OR: [
          { id: cartId },
          { userId: userId },
          { sessionId: sessionId }
        ]
      },
      include: {
        items: {
          include: {
            product: true
          }
        }
      }
    })

    if (!cart || cart.items.length === 0) {
      return NextResponse.json(
        { error: 'Panier vide ou introuvable' },
        { status: 400 }
      )
    }

    // Calculate total in EUR (cents for Stripe)
    const totalEUR = cart.items.reduce((sum, item) => {
      return sum + (item.product.price * item.quantity)
    }, 0)

    const totalCents = Math.round(totalEUR * 100) // Convert to cents

    // Create line items for Stripe
    const lineItems = cart.items.map(item => ({
      price_data: {
        currency: 'eur',
        product_data: {
          name: item.product.name,
          description: item.product.description || undefined,
          images: item.product.logo ? [item.product.logo] : undefined,
        },
        unit_amount: Math.round(item.product.price * 100), // Convert to cents
      },
      quantity: item.quantity,
    }))

    // Create Stripe checkout session or simulate it
    let checkoutSession: any

    if (isDummyKey) {
      // Simulation mode for testing with dummy keys
      console.log('🧪 Mode simulation Stripe activé (clés de test factices)')
      checkoutSession = {
        id: `cs_test_simulation_${Date.now()}`,
        url: `${process.env.NEXTAUTH_URL}/payment/simulation?session_id=cs_test_simulation_${Date.now()}`,
        payment_status: 'unpaid',
        metadata: {
          cartId: cart.id,
          userId: userId || '',
          sessionId: sessionId || '',
          totalEUR: totalEUR.toString(),
        }
      }
    } else {
      // Real Stripe checkout session
      checkoutSession = await stripe!.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: lineItems,
        mode: 'payment',
        success_url: `${process.env.NEXTAUTH_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.NEXTAUTH_URL}/panier`,
        metadata: {
          cartId: cart.id,
          userId: userId || '',
          sessionId: sessionId || '',
          totalEUR: totalEUR.toString(),
        },
        customer_email: session?.user?.email || undefined,
        billing_address_collection: 'required',
        shipping_address_collection: {
          allowed_countries: ['FR', 'BE', 'CH', 'LU', 'MC', 'AD'], // European countries
        },
      })
    }

    // Create order record (skip in simulation mode)
    let order = null
    if (!isDummyKey) {
      order = await prisma.order.create({
        data: {
          userId: userId || 'guest',
          total: totalEUR,
          status: 'PENDING',
          paymentId: checkoutSession.id,
          paymentMethod: 'STRIPE',
          items: {
            create: cart.items.map(item => ({
              productId: item.productId,
              quantity: item.quantity,
              price: item.product.price
            }))
          }
        }
      })
    }

    return NextResponse.json({
      sessionId: checkoutSession.id,
      url: checkoutSession.url,
      orderId: order?.id || 'simulation-mode'
    })

  } catch (error) {
    console.error('Stripe payment error:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la création de la session de paiement' },
      { status: 500 }
    )
  }
}