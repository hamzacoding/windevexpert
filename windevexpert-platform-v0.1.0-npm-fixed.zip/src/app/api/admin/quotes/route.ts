import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    // Vérification de l'authentification admin
    const session = await getServerSession(authOptions)
    
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Accès non autorisé' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const status = searchParams.get('status')
    const search = searchParams.get('search')

    const skip = (page - 1) * limit

    // Construction des filtres
    const where: any = {}
    
    if (status && status !== 'all') {
      where.status = status
    }
    
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { company: { contains: search, mode: 'insensitive' } },
        { projectTitle: { contains: search, mode: 'insensitive' } },
        { quoteNumber: { contains: search, mode: 'insensitive' } }
      ]
    }

    // Récupération des demandes de devis
    const [quotes, totalCount] = await Promise.all([
      prisma.quoteRequest.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          quoteNumber: true,
          firstName: true,
          lastName: true,
          email: true,
          phone: true,
          company: true,
          projectType: true,
          projectTitle: true,
          projectDescription: true,
          services: true,
          budget: true,
          timeline: true,
          status: true,
          estimatedPrice: true,
          quoteSentAt: true,
          createdAt: true,
          updatedAt: true
        }
      }),
      prisma.quoteRequest.count({ where })
    ])

    // Transformation des données
    const formattedQuotes = quotes.map(quote => ({
      ...quote,
      services: JSON.parse(quote.services || '[]'),
      fullName: `${quote.firstName} ${quote.lastName}`
    }))

    // Statistiques
    const stats = await prisma.quoteRequest.groupBy({
      by: ['status'],
      _count: {
        status: true
      }
    })

    const statusStats = stats.reduce((acc, stat) => {
      acc[stat.status] = stat._count.status
      return acc
    }, {} as Record<string, number>)

    return NextResponse.json({
      quotes: formattedQuotes,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(totalCount / limit),
        totalCount,
        hasNext: page * limit < totalCount,
        hasPrev: page > 1
      },
      stats: statusStats
    })

  } catch (error) {
    console.error('Erreur lors de la récupération des demandes de devis:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}