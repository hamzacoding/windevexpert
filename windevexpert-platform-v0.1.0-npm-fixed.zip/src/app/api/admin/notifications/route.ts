import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })
    }

    // Vérifier si l'utilisateur est admin
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { role: true }
    })

    if (user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
    }

    const now = new Date()
    const last24Hours = new Date(now.getTime() - 24 * 60 * 60 * 1000)

    // Récupérer les nouvelles demandes de devis (dernières 24h)
    const newQuotes = await prisma.quoteRequest.findMany({
      where: {
        createdAt: {
          gte: last24Hours
        },
        status: 'PENDING'
      },
      select: {
        id: true,
        projectTitle: true,
        firstName: true,
        lastName: true,
        email: true,
        createdAt: true,
        projectType: true
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 10
    })

    // Récupérer les nouvelles commandes (dernières 24h)
    const newOrders = await prisma.order.findMany({
      where: {
        createdAt: {
          gte: last24Hours
        },
        status: 'PENDING'
      },
      select: {
        id: true,
        user: {
          select: {
            name: true,
            email: true
          }
        },
        total: true,
        createdAt: true
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 10
    })

    // Récupérer les messages de contact récents (dernières 24h)
    // Note: La table ContactMessage n'existe pas encore dans le schéma
    const newMessages: any[] = []

    // Construire les notifications
    const notifications = [
      ...newQuotes.map(quote => ({
        id: `quote-${quote.id}`,
        type: 'quote' as const,
        title: 'Nouvelle demande de devis',
        message: `${quote.firstName} ${quote.lastName} a demandé un devis pour "${quote.projectTitle}"`,
        link: `/nimda/quotes/${quote.id}`,
        createdAt: quote.createdAt.toISOString(),
        read: false
      })),
      ...newOrders.map(order => ({
        id: `order-${order.id}`,
        type: 'order' as const,
        title: 'Nouvelle commande',
        message: `${order.user.name} a passé une commande de ${order.total}€`,
        link: `/nimda/orders/${order.id}`,
        createdAt: order.createdAt.toISOString(),
        read: false
      })),
      ...newMessages.map(message => ({
        id: `message-${message.id}`,
        type: 'message' as const,
        title: 'Nouveau message de contact',
        message: `${message.name}: ${message.subject}`,
        link: `/nimda/messages/${message.id}`,
        createdAt: message.createdAt.toISOString(),
        read: false
      }))
    ]

    // Trier par date de création (plus récent en premier)
    notifications.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    // Statistiques
    const stats = {
      newQuotes: newQuotes.length,
      newOrders: newOrders.length,
      newMessages: newMessages.length,
      total: newQuotes.length + newOrders.length + newMessages.length
    }

    return NextResponse.json({
      notifications,
      stats
    })

  } catch (error) {
    console.error('Erreur lors de la récupération des notifications:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}