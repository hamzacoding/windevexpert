import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get('x-slickpay-signature') || request.headers.get('signature')

    // Récupérer les paramètres de paiement pour la clé API
    const paymentSettings = await prisma.paymentSettings.findFirst()

    if (!paymentSettings || !paymentSettings.slickPaySecretKey) {
      console.error('Configuration SlickPay manquante')
      return NextResponse.json({ error: 'Configuration manquante' }, { status: 500 })
    }

    // Vérifier la signature du webhook si fournie
    if (signature) {
      const expectedSignature = crypto
        .createHmac('sha256', paymentSettings.slickPaySecretKey)
        .update(body)
        .digest('hex')

      if (signature !== expectedSignature) {
        console.error('Signature webhook invalide')
        return NextResponse.json({ error: 'Signature invalide' }, { status: 401 })
      }
    }

    const webhookData = JSON.parse(body)
    console.log('Webhook SlickPay reçu:', webhookData)

    // Traiter selon le type d'événement ou le statut
    const eventType = webhookData.event || webhookData.type
    const status = webhookData.status || webhookData.data?.status

    switch (eventType || status) {
      case 'payment.completed':
      case 'completed':
      case 'paid':
        await handlePaymentSuccess(webhookData.data || webhookData)
        break
      case 'payment.failed':
      case 'failed':
        await handlePaymentFailure(webhookData.data || webhookData)
        break
      case 'payment.cancelled':
      case 'cancelled':
      case 'expired':
        await handlePaymentExpired(webhookData.data || webhookData)
        break
      default:
        console.log('Type d\'événement non géré:', eventType || status)
    }

    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('Erreur lors du traitement du webhook SlickPay:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    )
  }
}

async function handlePaymentSuccess(paymentData: any) {
  try {
    const orderId = paymentData.order_id || paymentData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId },
      include: {
        user: true
      }
    })

    if (!invoice) {
      console.error('Facture non trouvée:', orderId)
      return
    }

    if (invoice.status === 'PAID') {
      console.log('Facture déjà payée:', orderId)
      return
    }

    // Mettre à jour la facture
    await prisma.invoice.update({
      where: { id: orderId },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        notes: `SlickPay Transaction ID: ${paymentData.id || paymentData.payment_id}`
      }
    })

    // Donner accès à la formation si c'est un produit de type formation
    if (invoice.productId) {
      const product = await prisma.product.findUnique({
        where: { id: invoice.productId },
        include: { courses: true }
      })

      if (product && product.type === 'TRAINING' && product.courses.length > 0) {
        const course = product.courses[0]
        
        // Vérifier si l'utilisateur n'est pas déjà inscrit
        const existingEnrollment = await prisma.enrollment.findUnique({
          where: {
            userId_courseId: {
              userId: invoice.userId,
              courseId: course.id
            }
          }
        })

        if (!existingEnrollment) {
          await prisma.enrollment.create({
            data: {
              userId: invoice.userId,
              courseId: course.id,
              enrolledAt: new Date()
            }
          })
        }
      }
    }

    // Créer une notification admin
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_VALIDATED',
        title: 'Paiement SlickPay validé',
        message: `Le paiement de ${invoice.totalAmount} DZD pour la facture ${invoice.invoiceNumber} a été validé automatiquement via SlickPay.`,
        invoiceId: invoice.id,
        userId: invoice.userId,
        priority: 'MEDIUM'
      }
    })

    console.log('Paiement SlickPay traité avec succès:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement du paiement réussi:', error)
  }
}

async function handlePaymentFailure(paymentData: any) {
  try {
    const orderId = paymentData.order_id || paymentData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook d\'échec')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId }
    })

    if (!invoice) {
      console.error('Facture non trouvée pour l\'échec:', orderId)
      return
    }

    // Mettre à jour la facture
    await prisma.invoice.update({
      where: { id: orderId },
      data: {
        status: 'REJECTED',
        rejectionReason: 'Paiement SlickPay échoué',
        notes: `SlickPay Payment Failed - ID: ${paymentData.id || paymentData.payment_id}`
      }
    })

    // Créer une notification admin
    await prisma.adminNotification.create({
      data: {
        type: 'PAYMENT_REJECTED',
        title: 'Paiement SlickPay échoué',
        message: `Le paiement SlickPay pour la facture ${invoice.invoiceNumber} a échoué.`,
        invoiceId: invoice.id,
        userId: invoice.userId,
        priority: 'HIGH'
      }
    })

    console.log('Échec de paiement SlickPay traité:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement de l\'échec de paiement:', error)
  }
}

async function handlePaymentExpired(paymentData: any) {
  try {
    const orderId = paymentData.order_id || paymentData.metadata?.invoice_id

    if (!orderId) {
      console.error('ID de commande manquant dans le webhook d\'expiration')
      return
    }

    // Trouver la facture
    const invoice = await prisma.invoice.findUnique({
      where: { id: orderId }
    })

    if (!invoice) {
      console.error('Facture non trouvée pour l\'expiration:', orderId)
      return
    }

    // Mettre à jour la facture
    await prisma.invoice.update({
      where: { id: orderId },
      data: {
        status: 'CANCELLED',
        notes: `SlickPay Payment Expired - ID: ${paymentData.id || paymentData.payment_id}`
      }
    })

    console.log('Expiration de paiement SlickPay traitée:', orderId)

  } catch (error) {
    console.error('Erreur lors du traitement de l\'expiration de paiement:', error)
  }
}