import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import '@/styles/animations.css'
import { Providers } from '@/components/providers'
import { PageWrapper } from '@/components/layout/page-wrapper'
import { ScrollToTop } from '@/components/ui/scroll-to-top'
import { Toaster } from 'react-hot-toast'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'WindevExpert - Plateforme SaaS de Développement',
  description: 'Plateforme SaaS pour services de développement, formations et gestion de projets',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          <PageWrapper>
            {children}
          </PageWrapper>
          <ScrollToTop />
          <Toaster position="top-right" />
        </Providers>
      </body>
    </html>
  )
}
